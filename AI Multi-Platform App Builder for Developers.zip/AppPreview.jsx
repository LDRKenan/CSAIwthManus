import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Monitor, Smartphone, Tablet, Maximize, RefreshCw, ExternalLink } from 'lucide-react'

export default function AppPreview({ project, platform = 'web' }) {
  const [previewMode, setPreviewMode] = useState('desktop')
  const [isLoading, setIsLoading] = useState(false)
  const [previewContent, setPreviewContent] = useState('')

  useEffect(() => {
    if (project) {
      generatePreview()
    }
  }, [project, platform, previewMode])

  const generatePreview = () => {
    if (!project?.generated_code?.files) return

    // Find the main app file for the selected platform
    const platformFiles = project.generated_code.files.filter(file => 
      file.platform === platform || (!file.platform && platform === 'web')
    )

    const appFile = platformFiles.find(file => 
      file.path.includes('App.') || file.path.includes('index.')
    )

    if (appFile && platform === 'web') {
      // Generate HTML preview for web platform
      const htmlContent = generateWebPreview(appFile.content, project)
      setPreviewContent(htmlContent)
    } else if (platform === 'android' || platform === 'ios') {
      // Generate mobile preview mockup
      const mobileContent = generateMobilePreview(project, platform)
      setPreviewContent(mobileContent)
    }
  }

  const generateWebPreview = (appContent, project) => {
    // Extract key information from the React component
    const projectName = project.name || 'My App'
    const description = project.description || 'A modern application'
    
    // Create a functional HTML preview
    return `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${projectName}</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .app-container {
            background: white;
            border-radius: 20px;
            padding: 2rem;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            max-width: 800px;
            width: 90%;
            animation: fadeIn 0.5s ease-out;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .app-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        
        .app-title {
            font-size: 2.5rem;
            font-weight: bold;
            background: linear-gradient(135deg, #667eea, #764ba2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 0.5rem;
        }
        
        .app-description {
            color: #666;
            font-size: 1.1rem;
            line-height: 1.6;
        }
        
        .platform-badges {
            display: flex;
            justify-content: center;
            gap: 0.5rem;
            margin: 1rem 0;
            flex-wrap: wrap;
        }
        
        .badge {
            background: #f0f0f0;
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 500;
            color: #333;
        }
        
        .features {
            margin-top: 2rem;
        }
        
        .features h2 {
            font-size: 1.5rem;
            margin-bottom: 1rem;
            color: #333;
        }
        
        .features ul {
            list-style: none;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1rem;
        }
        
        .features li {
            background: #f8f9fa;
            padding: 1rem;
            border-radius: 10px;
            border-left: 4px solid #667eea;
            transition: transform 0.2s ease;
        }
        
        .features li:hover {
            transform: translateX(5px);
        }
        
        .ai-badge {
            text-align: center;
            margin-top: 2rem;
            padding: 1rem;
            background: linear-gradient(135deg, #667eea, #764ba2);
            border-radius: 10px;
            color: white;
        }
        
        .dashboard {
            margin-top: 2rem;
            padding: 1.5rem;
            background: #f8f9fa;
            border-radius: 15px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 1rem;
            margin-top: 1rem;
        }
        
        .stat-card {
            background: white;
            padding: 1rem;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .stat-card h3 {
            font-size: 2rem;
            color: #667eea;
            margin-bottom: 0.5rem;
        }
        
        .stat-card p {
            color: #666;
            font-size: 0.9rem;
        }
        
        @media (max-width: 768px) {
            .app-container {
                padding: 1rem;
                margin: 1rem;
            }
            
            .app-title {
                font-size: 2rem;
            }
            
            .features ul {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="app-container">
        <div class="app-header">
            <h1 class="app-title">${projectName}</h1>
            <p class="app-description">${description}</p>
            <div class="platform-badges">
                ${project.platforms.map(p => `<span class="badge">${p.toUpperCase()}</span>`).join('')}
            </div>
            <div class="ai-badge">
                <span>🤖 Generated with Groq AI</span>
            </div>
        </div>
        
        <div class="features">
            <h2>Key Features:</h2>
            <ul>
                ${project.platforms.includes('web') ? '<li>🌐 Responsive web interface</li>' : ''}
                ${project.platforms.includes('mobile') ? '<li>📱 Mobile-optimized design</li>' : ''}
                ${project.platforms.includes('android') ? '<li>🤖 Android native features</li>' : ''}
                ${project.platforms.includes('ios') ? '<li>🍎 iOS native integration</li>' : ''}
                <li>⚡ AI-powered architecture</li>
                <li>🎨 Modern design patterns</li>
                <li>🔒 Secure authentication</li>
                <li>📊 Real-time analytics</li>
            </ul>
        </div>
        
        <div class="dashboard">
            <h2>📊 Dashboard</h2>
            <p>Welcome to your ${project.appType} application!</p>
            <div class="stats-grid">
                <div class="stat-card">
                    <h3>${Math.floor(Math.random() * 1000) + 100}</h3>
                    <p>Active Users</p>
                </div>
                <div class="stat-card">
                    <h3>${Math.floor(Math.random() * 50) + 10}</h3>
                    <p>Projects</p>
                </div>
                <div class="stat-card">
                    <h3>${project.platforms.length}</h3>
                    <p>Platforms</p>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Add some interactivity
        document.addEventListener('DOMContentLoaded', function() {
            const statCards = document.querySelectorAll('.stat-card');
            statCards.forEach(card => {
                card.addEventListener('click', function() {
                    this.style.transform = 'scale(1.05)';
                    setTimeout(() => {
                        this.style.transform = 'scale(1)';
                    }, 200);
                });
            });
            
            // Animate numbers
            const numbers = document.querySelectorAll('.stat-card h3');
            numbers.forEach(num => {
                const finalValue = parseInt(num.textContent);
                let currentValue = 0;
                const increment = finalValue / 50;
                
                const timer = setInterval(() => {
                    currentValue += increment;
                    if (currentValue >= finalValue) {
                        currentValue = finalValue;
                        clearInterval(timer);
                    }
                    num.textContent = Math.floor(currentValue);
                }, 20);
            });
        });
    </script>
</body>
</html>`
  }

  const generateMobilePreview = (project, platform) => {
    const platformName = platform === 'android' ? 'Android' : 'iOS'
    const bgColor = platform === 'android' ? '#4CAF50' : '#007AFF'
    
    return `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${project.name} - ${platformName}</title>
    <style>
        body {
            margin: 0;
            padding: 20px;
            background: #f0f0f0;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        
        .phone-mockup {
            width: 300px;
            height: 600px;
            background: #333;
            border-radius: 30px;
            padding: 20px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.3);
            position: relative;
        }
        
        .screen {
            width: 100%;
            height: 100%;
            background: white;
            border-radius: 20px;
            overflow: hidden;
            position: relative;
        }
        
        .status-bar {
            height: 30px;
            background: ${bgColor};
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 15px;
            color: white;
            font-size: 12px;
        }
        
        .app-content {
            padding: 20px;
            height: calc(100% - 30px);
            overflow-y: auto;
        }
        
        .app-header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .app-title {
            font-size: 24px;
            font-weight: bold;
            color: ${bgColor};
            margin-bottom: 10px;
        }
        
        .app-description {
            font-size: 14px;
            color: #666;
            line-height: 1.4;
        }
        
        .feature-list {
            list-style: none;
            padding: 0;
            margin: 20px 0;
        }
        
        .feature-list li {
            background: #f8f9fa;
            margin: 10px 0;
            padding: 15px;
            border-radius: 10px;
            border-left: 4px solid ${bgColor};
            font-size: 14px;
        }
        
        .platform-badge {
            background: ${bgColor};
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 12px;
            display: inline-block;
            margin: 10px auto;
        }
        
        .bottom-nav {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            height: 60px;
            background: white;
            border-top: 1px solid #eee;
            display: flex;
            justify-content: space-around;
            align-items: center;
        }
        
        .nav-item {
            text-align: center;
            color: #666;
            font-size: 12px;
        }
        
        .nav-item.active {
            color: ${bgColor};
        }
    </style>
</head>
<body>
    <div class="phone-mockup">
        <div class="screen">
            <div class="status-bar">
                <span>9:41</span>
                <span>${platformName}</span>
                <span>100%</span>
            </div>
            
            <div class="app-content">
                <div class="app-header">
                    <h1 class="app-title">${project.name}</h1>
                    <p class="app-description">${project.description}</p>
                    <div class="platform-badge">${platformName} App</div>
                </div>
                
                <ul class="feature-list">
                    <li>📱 Native ${platformName} experience</li>
                    <li>🔔 Push notifications</li>
                    <li>📍 Location services</li>
                    <li>📷 Camera integration</li>
                    <li>💾 Offline storage</li>
                    <li>🔒 Biometric authentication</li>
                </ul>
            </div>
            
            <div class="bottom-nav">
                <div class="nav-item active">
                    <div>🏠</div>
                    <div>Home</div>
                </div>
                <div class="nav-item">
                    <div>🔍</div>
                    <div>Search</div>
                </div>
                <div class="nav-item">
                    <div>❤️</div>
                    <div>Favorites</div>
                </div>
                <div class="nav-item">
                    <div>👤</div>
                    <div>Profile</div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>`
  }

  const getPreviewDimensions = () => {
    switch (previewMode) {
      case 'mobile':
        return { width: '375px', height: '667px' }
      case 'tablet':
        return { width: '768px', height: '1024px' }
      default:
        return { width: '100%', height: '600px' }
    }
  }

  const handleRefresh = () => {
    setIsLoading(true)
    setTimeout(() => {
      generatePreview()
      setIsLoading(false)
    }, 1000)
  }

  if (!project) {
    return (
      <Card>
        <CardContent className="text-center py-12">
          <Monitor className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium mb-2">No Preview Available</h3>
          <p className="text-gray-600">Generate an app first to see the live preview</p>
        </CardContent>
      </Card>
    )
  }

  const dimensions = getPreviewDimensions()

  return (
    <div className="space-y-4">
      {/* Preview Controls */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Button
            variant={previewMode === 'desktop' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setPreviewMode('desktop')}
          >
            <Monitor className="w-4 h-4 mr-1" />
            Desktop
          </Button>
          <Button
            variant={previewMode === 'tablet' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setPreviewMode('tablet')}
          >
            <Tablet className="w-4 h-4 mr-1" />
            Tablet
          </Button>
          <Button
            variant={previewMode === 'mobile' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setPreviewMode('mobile')}
          >
            <Smartphone className="w-4 h-4 mr-1" />
            Mobile
          </Button>
        </div>
        
        <div className="flex items-center gap-2">
          <Badge variant="secondary">{platform}</Badge>
          <Button variant="outline" size="sm" onClick={handleRefresh} disabled={isLoading}>
            <RefreshCw className={`w-4 h-4 mr-1 ${isLoading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          <Button variant="outline" size="sm">
            <Maximize className="w-4 h-4 mr-1" />
            Fullscreen
          </Button>
        </div>
      </div>

      {/* Preview Frame */}
      <div className="border rounded-lg overflow-hidden bg-gray-100 p-4">
        <div 
          className="mx-auto bg-white rounded-lg shadow-lg overflow-hidden"
          style={{ 
            width: dimensions.width, 
            height: dimensions.height,
            maxWidth: '100%'
          }}
        >
          {previewContent ? (
            <iframe
              srcDoc={previewContent}
              className="w-full h-full border-0"
              title={`${project.name} Preview`}
              sandbox="allow-scripts allow-same-origin"
            />
          ) : (
            <div className="flex items-center justify-center h-full">
              <div className="text-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mx-auto mb-4"></div>
                <p className="text-gray-600">Generating preview...</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Preview Info */}
      <div className="flex items-center justify-between text-sm text-gray-500">
        <span>
          Platform: {platform} • Mode: {previewMode} • Generated with Groq AI
        </span>
        <span>
          {dimensions.width} × {dimensions.height}
        </span>
      </div>
    </div>
  )
}

