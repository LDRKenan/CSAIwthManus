import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { 
  Sparkles, 
  Zap, 
  Globe, 
  Smartphone, 
  Cpu,
  ArrowRight,
  Play,
  Stars
} from 'lucide-react'

export default function Hero() {
  const [projectIdea, setProjectIdea] = useState('')
  const [selectedPlatform, setSelectedPlatform] = useState('ALL')

  const platforms = [
    { id: 'WEB', label: 'ONLY WEB', color: 'purple' },
    { id: 'MOBILE', label: 'ONLY MOBILE', color: 'green' },
    { id: 'ANDROID', label: 'ONLY ANDROID', color: 'blue' },
    { id: 'IOS', label: 'ONLY iOS', color: 'orange' },
    { id: 'ALL', label: 'ALL', color: 'gradient' }
  ]

  const quickTemplates = [
    { name: 'Instagram Clone', icon: '📸', gradient: 'from-pink-500 to-rose-500' },
    { name: 'Food Delivery', icon: '🍕', gradient: 'from-orange-500 to-red-500' },
    { name: 'E-commerce', icon: '🛒', gradient: 'from-blue-500 to-purple-500' },
    { name: 'Task Manager', icon: '✅', gradient: 'from-green-500 to-teal-500' }
  ]

  const handleCreateWithAI = () => {
    if (!projectIdea.trim()) {
      alert('Please describe your project idea first!')
      return
    }
    
    // Navigate to app builder with the project idea and platform
    const searchParams = new URLSearchParams({
      idea: projectIdea,
      platform: selectedPlatform
    })
    window.location.href = `#app-builder?${searchParams.toString()}`
  }

  return (
    <div className="relative overflow-hidden bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50">
      {/* Background Effects */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-purple-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-blob"></div>
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-yellow-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-blob animation-delay-2000"></div>
        <div className="absolute -bottom-8 left-1/3 w-96 h-96 bg-pink-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-blob animation-delay-4000"></div>
      </div>

      <div className="relative container mx-auto px-4 py-20">
        <div className="text-center max-w-4xl mx-auto">
          {/* Badge */}
          <div className="inline-flex items-center px-4 py-2 rounded-full bg-white/80 backdrop-blur-sm border border-purple-200 mb-8">
            <Stars className="w-4 h-4 text-purple-600 mr-2" />
            <span className="text-sm font-medium text-purple-700">AI-Powered Development</span>
          </div>

          {/* Main Heading */}
          <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
            <span className="bg-gradient-to-r from-gray-900 via-purple-900 to-blue-900 bg-clip-text text-transparent">
              From Idea to App
            </span>
            <br />
            <span className="bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 bg-clip-text text-transparent">
              In Seconds
            </span>
          </h1>

          {/* Subtitle */}
          <p className="text-xl md:text-2xl text-gray-600 mb-12 max-w-3xl mx-auto leading-relaxed">
            Describe your project idea and AI will automatically create multi-platform 
            <span className="font-semibold text-purple-700"> (Android, iOS, Web) </span>
            applications. Real code, real deployment, real results.
          </p>

          {/* Platform Badges */}
          <div className="flex justify-center items-center space-x-6 mb-12">
            <div className="flex items-center space-x-2 px-4 py-2 bg-white/80 backdrop-blur-sm rounded-full border border-blue-200">
              <Globe className="w-5 h-5 text-blue-600" />
              <span className="font-medium text-blue-700">Web</span>
            </div>
            <div className="flex items-center space-x-2 px-4 py-2 bg-white/80 backdrop-blur-sm rounded-full border border-green-200">
              <Smartphone className="w-5 h-5 text-green-600" />
              <span className="font-medium text-green-700">Mobile</span>
            </div>
            <div className="flex items-center space-x-2 px-4 py-2 bg-white/80 backdrop-blur-sm rounded-full border border-purple-200">
              <Cpu className="w-5 h-5 text-purple-600" />
              <span className="font-medium text-purple-700">AI Powered</span>
            </div>
          </div>

          {/* Input Section */}
          <div className="max-w-2xl mx-auto mb-8">
            <h3 className="text-2xl font-semibold text-gray-800 mb-6">Describe your project idea</h3>
            
            {/* Platform Selection */}
            <div className="mb-6">
              <div className="flex flex-wrap justify-center gap-3 mb-4">
                {platforms.map((platform) => (
                  <button
                    key={platform.id}
                    onClick={() => setSelectedPlatform(platform.id)}
                    className={`px-4 py-2 rounded-xl text-sm font-medium transition-all duration-200 ${
                      selectedPlatform === platform.id
                        ? platform.color === 'gradient'
                          ? 'bg-gradient-to-r from-purple-600 to-blue-600 text-white shadow-lg'
                          : `bg-${platform.color}-100 border-2 border-${platform.color}-400 text-${platform.color}-700`
                        : platform.color === 'gradient'
                          ? 'bg-white/80 backdrop-blur-sm border-2 border-purple-200 text-purple-700 hover:border-purple-400 hover:bg-purple-50'
                          : `bg-white/80 backdrop-blur-sm border-2 border-${platform.color}-200 text-${platform.color}-700 hover:border-${platform.color}-400 hover:bg-${platform.color}-50`
                    }`}
                  >
                    {platform.label}
                  </button>
                ))}
              </div>
            </div>
            
            <div className="relative">
              <Input
                placeholder="e.g., Instagram-like social media app, food delivery service..."
                value={projectIdea}
                onChange={(e) => setProjectIdea(e.target.value)}
                className="w-full h-14 text-lg px-6 pr-32 rounded-2xl border-2 border-purple-200 focus:border-purple-400 focus:ring-4 focus:ring-purple-100 bg-white/80 backdrop-blur-sm"
              />
              <Button 
                onClick={handleCreateWithAI}
                className="absolute right-2 top-2 h-10 px-6 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 rounded-xl"
              >
                <Sparkles className="w-4 h-4 mr-2" />
                Create with AI
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>

            {/* Quick Templates */}
            <div className="mt-6">
              <p className="text-sm text-gray-500 mb-4">Or try a quick template:</p>
              <div className="flex flex-wrap justify-center gap-3">
                {quickTemplates.map((template, index) => (
                  <button
                    key={index}
                    onClick={() => setProjectIdea(`${template.name.toLowerCase()} app`)}
                    className={`flex items-center space-x-2 px-4 py-2 rounded-xl bg-gradient-to-r ${template.gradient} text-white hover:scale-105 transition-all duration-200 shadow-lg hover:shadow-xl`}
                  >
                    <span className="text-lg">{template.icon}</span>
                    <span className="font-medium">{template.name}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* CTA Button */}
          <Button 
            onClick={handleCreateWithAI}
            size="lg"
            className="h-16 px-12 text-lg font-semibold bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 hover:from-purple-700 hover:via-pink-700 hover:to-blue-700 rounded-2xl shadow-2xl hover:shadow-purple-500/25 transition-all duration-300 transform hover:scale-105"
          >
            <Play className="w-6 h-6 mr-3" />
            Build My App with AI
            <Zap className="w-6 h-6 ml-3" />
          </Button>

          {/* Stats */}
          <div className="mt-12 text-center">
            <p className="text-sm text-gray-500 mb-4">⚡ Average creation time: 30-60 seconds</p>
            
            <div className="flex justify-center items-center space-x-8 text-sm text-gray-400">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gray-200 rounded-full"></div>
                <span>Trusted by developers</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gray-200 rounded-full"></div>
                <span>worldwide</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes blob {
          0% {
            transform: translate(0px, 0px) scale(1);
          }
          33% {
            transform: translate(30px, -50px) scale(1.1);
          }
          66% {
            transform: translate(-20px, 20px) scale(0.9);
          }
          100% {
            transform: translate(0px, 0px) scale(1);
          }
        }
        .animate-blob {
          animation: blob 7s infinite;
        }
        .animation-delay-2000 {
          animation-delay: 2s;
        }
        .animation-delay-4000 {
          animation-delay: 4s;
        }
      `}</style>
    </div>
  )
}

