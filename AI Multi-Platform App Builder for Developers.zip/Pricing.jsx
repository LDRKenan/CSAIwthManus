import { Check, Star, Zap, Users, Crown, Rocket } from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function Pricing() {
  const plans = [
    {
      name: "Free",
      price: "$0",
      period: "forever",
      description: "Perfect for trying out AI App Builder",
      icon: Star,
      iconColor: "text-gray-600",
      gradient: "from-gray-100 to-gray-200",
      buttonStyle: "bg-gray-600 hover:bg-gray-700 text-white",
      popular: false,
      features: [
        "10 questions per day",
        "Basic templates",
        "Web platform only",
        "Community support",
        "Basic code export"
      ],
      limitations: [
        "No deployment",
        "Limited customization"
      ]
    },
    {
      name: "Pro",
      price: "$30",
      period: "per month",
      description: "For individual developers and small projects",
      icon: Zap,
      iconColor: "text-blue-600",
      gradient: "from-blue-500 to-purple-600",
      buttonStyle: "bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white",
      popular: true,
      features: [
        "50 questions per day",
        "All templates & frameworks",
        "Multi-platform support",
        "Priority support",
        "Advanced code export",
        "Limited deployment (small volume)",
        "Real-time collaboration",
        "Version control"
      ],
      limitations: []
    },
    {
      name: "VIP",
      price: "$50",
      period: "per month",
      description: "For professional developers and agencies",
      icon: Crown,
      iconColor: "text-purple-600",
      gradient: "from-purple-500 to-pink-600",
      buttonStyle: "bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white",
      popular: false,
      features: [
        "Unlimited questions",
        "All Pro features",
        "Premium templates",
        "Advanced AI models",
        "Custom branding",
        "Limited deployment (large volume)",
        "API access",
        "Advanced analytics"
      ],
      limitations: []
    },
    {
      name: "Team VIP",
      price: "$200",
      period: "per month",
      description: "For teams of up to 5 developers",
      icon: Users,
      iconColor: "text-green-600",
      gradient: "from-green-500 to-teal-600",
      buttonStyle: "bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700 text-white",
      popular: false,
      features: [
        "Everything in VIP",
        "5 team members",
        "Team collaboration tools",
        "Shared workspaces",
        "Team analytics",
        "Unlimited deployment",
        "White-label solutions",
        "Dedicated support"
      ],
      limitations: []
    }
  ]

  return (
    <section id="pricing" className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="bg-gradient-to-r from-gray-900 to-gray-600 bg-clip-text text-transparent">
              Choose Your
            </span>
            <br />
            <span className="bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              Perfect Plan
            </span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Start free and scale as you grow. All plans include our core AI-powered development features.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-7xl mx-auto">
          {plans.map((plan, index) => (
            <div
              key={index}
              className={`relative bg-white rounded-3xl p-8 border-2 transition-all duration-300 hover:shadow-2xl hover:-translate-y-2 ${
                plan.popular 
                  ? 'border-purple-200 shadow-xl scale-105' 
                  : 'border-gray-100 hover:border-gray-200'
              }`}
            >
              {/* Popular Badge */}
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white px-6 py-2 rounded-full text-sm font-semibold">
                    Most Popular
                  </div>
                </div>
              )}

              {/* Icon */}
              <div className={`w-16 h-16 rounded-2xl bg-gradient-to-r ${plan.gradient} flex items-center justify-center mb-6`}>
                <plan.icon className={`w-8 h-8 text-white`} />
              </div>

              {/* Plan Name */}
              <h3 className="text-2xl font-bold text-gray-900 mb-2">
                {plan.name}
              </h3>

              {/* Price */}
              <div className="mb-4">
                <span className="text-4xl font-bold text-gray-900">
                  {plan.price}
                </span>
                <span className="text-gray-600 ml-2">
                  {plan.period}
                </span>
              </div>

              {/* Description */}
              <p className="text-gray-600 mb-6">
                {plan.description}
              </p>

              {/* CTA Button */}
              <Button 
                className={`w-full h-12 rounded-xl font-semibold mb-8 ${plan.buttonStyle} transition-all duration-300 hover:scale-105`}
              >
                {plan.name === 'Free' ? 'Get Started' : 'Start Free Trial'}
              </Button>

              {/* Features */}
              <div className="space-y-4">
                <h4 className="font-semibold text-gray-900 mb-3">What's included:</h4>
                {plan.features.map((feature, featureIndex) => (
                  <div key={featureIndex} className="flex items-start space-x-3">
                    <Check className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-600 text-sm">
                      {feature}
                    </span>
                  </div>
                ))}
                
                {/* Limitations */}
                {plan.limitations.length > 0 && (
                  <div className="pt-4 border-t border-gray-100">
                    <h5 className="font-medium text-gray-500 mb-2 text-sm">Limitations:</h5>
                    {plan.limitations.map((limitation, limitIndex) => (
                      <div key={limitIndex} className="flex items-start space-x-3">
                        <div className="w-5 h-5 mt-0.5 flex-shrink-0">
                          <div className="w-1 h-1 bg-gray-400 rounded-full mx-auto mt-2"></div>
                        </div>
                        <span className="text-gray-500 text-sm">
                          {limitation}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* FAQ Section */}
        <div className="mt-20 text-center">
          <h3 className="text-2xl font-bold text-gray-900 mb-8">
            Frequently Asked Questions
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto text-left">
            <div className="bg-white rounded-2xl p-6 border border-gray-100">
              <h4 className="font-semibold text-gray-900 mb-3">
                What counts as a "question"?
              </h4>
              <p className="text-gray-600">
                Each AI request to generate, modify, or analyze code counts as one question. This includes project generation, code editing, and architectural advice.
              </p>
            </div>
            
            <div className="bg-white rounded-2xl p-6 border border-gray-100">
              <h4 className="font-semibold text-gray-900 mb-3">
                Can I upgrade or downgrade anytime?
              </h4>
              <p className="text-gray-600">
                Yes! You can change your plan at any time. Upgrades take effect immediately, and downgrades take effect at the next billing cycle.
              </p>
            </div>
            
            <div className="bg-white rounded-2xl p-6 border border-gray-100">
              <h4 className="font-semibold text-gray-900 mb-3">
                What's included in deployment limits?
              </h4>
              <p className="text-gray-600">
                Small volume: up to 1,000 monthly visitors. Large volume: up to 10,000 monthly visitors. Team VIP includes unlimited deployment.
              </p>
            </div>
            
            <div className="bg-white rounded-2xl p-6 border border-gray-100">
              <h4 className="font-semibold text-gray-900 mb-3">
                Do you offer refunds?
              </h4>
              <p className="text-gray-600">
                We offer a 14-day money-back guarantee for all paid plans. No questions asked if you're not satisfied.
              </p>
            </div>
          </div>
        </div>

        {/* Enterprise CTA */}
        <div className="mt-16 text-center bg-gradient-to-r from-purple-600 to-blue-600 rounded-3xl p-12 text-white">
          <Rocket className="w-16 h-16 mx-auto mb-6" />
          <h3 className="text-3xl font-bold mb-4">
            Need something bigger?
          </h3>
          <p className="text-xl mb-8 opacity-90">
            Enterprise solutions with custom features, dedicated support, and unlimited everything.
          </p>
          <Button className="bg-white text-purple-600 hover:bg-gray-100 font-semibold px-8 py-3 rounded-xl">
            Contact Sales
          </Button>
        </div>
      </div>
    </section>
  )
}

