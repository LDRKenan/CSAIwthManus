from flask import Blueprint, jsonify, request, send_file
from src.models.project import Project, db
import json
import zipfile
import os
import tempfile
import shutil
from datetime import datetime

export_bp = Blueprint('export', __name__)

class ProjectTemplates:
    """Project template generators for different frameworks"""
    
    @staticmethod
    def generate_react_template(project):
        """Generate React/Next.js project template"""
        
        files = {
            'package.json': {
                'content': json.dumps({
                    "name": project.name.lower().replace(' ', '-'),
                    "version": "1.0.0",
                    "description": project.description,
                    "private": True,
                    "scripts": {
                        "dev": "next dev",
                        "build": "next build",
                        "start": "next start",
                        "lint": "next lint"
                    },
                    "dependencies": {
                        "next": "14.0.0",
                        "react": "^18.2.0",
                        "react-dom": "^18.2.0",
                        "tailwindcss": "^3.3.0",
                        "autoprefixer": "^10.4.16",
                        "postcss": "^8.4.31"
                    },
                    "devDependencies": {
                        "eslint": "^8.52.0",
                        "eslint-config-next": "14.0.0"
                    }
                }, indent=2),
                'type': 'json'
            },
            'next.config.js': {
                'content': '''/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    appDir: true,
  },
}

module.exports = nextConfig
''',
                'type': 'javascript'
            },
            'tailwind.config.js': {
                'content': '''/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
''',
                'type': 'javascript'
            },
            'app/layout.js': {
                'content': f'''import './globals.css'

export const metadata = {{
  title: '{project.name}',
  description: '{project.description}',
}}

export default function RootLayout({{ children }}) {{
  return (
    <html lang="tr">
      <body>{{children}}</body>
    </html>
  )
}}
''',
                'type': 'javascript'
            },
            'app/page.js': {
                'content': f'''export default function Home() {{
  return (
    <main className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold text-center mb-8">
          {project.name}
        </h1>
        <p className="text-xl text-gray-600 text-center mb-12">
          {project.description}
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold mb-4">Özellik 1</h2>
            <p className="text-gray-600">Bu özellik hakkında açıklama</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold mb-4">Özellik 2</h2>
            <p className="text-gray-600">Bu özellik hakkında açıklama</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold mb-4">Özellik 3</h2>
            <p className="text-gray-600">Bu özellik hakkında açıklama</p>
          </div>
        </div>
      </div>
    </main>
  )
}}
''',
                'type': 'javascript'
            },
            'app/globals.css': {
                'content': '''@tailwind base;
@tailwind components;
@tailwind utilities;

body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
''',
                'type': 'css'
            },
            'README.md': {
                'content': f'''# {project.name}

{project.description}

## Başlangıç

Bu proje AI App Builder ile oluşturulmuştur.

### Gereksinimler

- Node.js 18+
- npm veya yarn

### Kurulum

```bash
npm install
# veya
yarn install
```

### Geliştirme Sunucusu

```bash
npm run dev
# veya
yarn dev
```

Tarayıcınızda [http://localhost:3000](http://localhost:3000) adresini açın.

### Build

```bash
npm run build
# veya
yarn build
```

## Deployment

Bu proje Vercel, Netlify veya herhangi bir static hosting servisinde deploy edilebilir.

## Teknolojiler

- Next.js 14
- React 18
- Tailwind CSS
- TypeScript (opsiyonel)

## Lisans

MIT
''',
                'type': 'markdown'
            }
        }
        
        return files
    
    @staticmethod
    def generate_react_native_template(project):
        """Generate React Native project template"""
        
        files = {
            'package.json': {
                'content': json.dumps({
                    "name": project.name.lower().replace(' ', '-'),
                    "version": "1.0.0",
                    "description": project.description,
                    "main": "index.js",
                    "scripts": {
                        "android": "react-native run-android",
                        "ios": "react-native run-ios",
                        "start": "react-native start",
                        "test": "jest",
                        "lint": "eslint ."
                    },
                    "dependencies": {
                        "react": "18.2.0",
                        "react-native": "0.72.6",
                        "@react-navigation/native": "^6.1.9",
                        "@react-navigation/stack": "^6.3.20",
                        "react-native-screens": "^3.27.0",
                        "react-native-safe-area-context": "^4.7.4"
                    },
                    "devDependencies": {
                        "@babel/core": "^7.20.0",
                        "@babel/preset-env": "^7.20.0",
                        "@babel/runtime": "^7.20.0",
                        "eslint": "^8.19.0",
                        "jest": "^29.2.1",
                        "metro-react-native-babel-preset": "0.76.8"
                    }
                }, indent=2),
                'type': 'json'
            },
            'App.js': {
                'content': f'''import React from 'react';
import {{
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  View,
}} from 'react-native';

function App() {{
  return (
    <SafeAreaView style={{flex: 1}}>
      <StatusBar barStyle="dark-content" />
      <ScrollView contentInsetAdjustmentBehavior="automatic">
        <View style={styles.container}>
          <Text style={styles.title}>{project.name}</Text>
          <Text style={styles.description}>
            {project.description}
          </Text>
          
          <View style={styles.featuresContainer}>
            <View style={styles.feature}>
              <Text style={styles.featureTitle}>Özellik 1</Text>
              <Text style={styles.featureText}>Bu özellik hakkında açıklama</Text>
            </View>
            <View style={styles.feature}>
              <Text style={styles.featureTitle}>Özellik 2</Text>
              <Text style={styles.featureText}>Bu özellik hakkında açıklama</Text>
            </View>
            <View style={styles.feature}>
              <Text style={styles.featureTitle}>Özellik 3</Text>
              <Text style={styles.featureText}>Bu özellik hakkında açıklama</Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}}

const styles = StyleSheet.create({{
  container: {{
    flex: 1,
    padding: 20,
    backgroundColor: '#f5f5f5',
  }},
  title: {{
    fontSize: 32,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 16,
    color: '#333',
  }},
  description: {{
    fontSize: 18,
    textAlign: 'center',
    marginBottom: 32,
    color: '#666',
  }},
  featuresContainer: {{
    gap: 16,
  }},
  feature: {{
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: {{
      width: 0,
      height: 2,
    }},
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  }},
  featureTitle: {{
    fontSize: 20,
    fontWeight: '600',
    marginBottom: 8,
    color: '#333',
  }},
  featureText: {{
    fontSize: 16,
    color: '#666',
  }},
}});

export default App;
''',
                'type': 'javascript'
            },
            'index.js': {
                'content': '''import {AppRegistry} from 'react-native';
import App from './App';
import {name as appName} from './app.json';

AppRegistry.registerComponent(appName, () => App);
''',
                'type': 'javascript'
            },
            'app.json': {
                'content': json.dumps({
                    "name": project.name.replace(' ', ''),
                    "displayName": project.name
                }, indent=2),
                'type': 'json'
            },
            'README.md': {
                'content': f'''# {project.name}

{project.description}

## Başlangıç

Bu proje AI App Builder ile oluşturulmuştur.

### Gereksinimler

- Node.js 18+
- React Native CLI
- Android Studio (Android için)
- Xcode (iOS için)

### Kurulum

```bash
npm install
# veya
yarn install
```

### iOS Çalıştırma

```bash
npx react-native run-ios
```

### Android Çalıştırma

```bash
npx react-native run-android
```

## Teknolojiler

- React Native 0.72
- React Navigation
- Native Base (UI Library)

## Lisans

MIT
''',
                'type': 'markdown'
            }
        }
        
        return files
    
    @staticmethod
    def generate_flutter_template(project):
        """Generate Flutter project template"""
        
        files = {
            'pubspec.yaml': {
                'content': f'''name: {project.name.lower().replace(' ', '_')}
description: {project.description}
version: 1.0.0+1

environment:
  sdk: '>=3.0.0 <4.0.0'

dependencies:
  flutter:
    sdk: flutter
  cupertino_icons: ^1.0.2
  http: ^1.1.0
  provider: ^6.1.1

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^3.0.0

flutter:
  uses-material-design: true
''',
                'type': 'yaml'
            },
            'lib/main.dart': {
                'content': f'''import 'package:flutter/material.dart';

void main() {{
  runApp(MyApp());
}}

class MyApp extends StatelessWidget {{
  @override
  Widget build(BuildContext context) {{
    return MaterialApp(
      title: '{project.name}',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: HomePage(),
    );
  }}
}}

class HomePage extends StatelessWidget {{
  @override
  Widget build(BuildContext context) {{
    return Scaffold(
      appBar: AppBar(
        title: Text('{project.name}'),
        backgroundColor: Colors.blue,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '{project.name}',
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 16),
            Text(
              '{project.description}',
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                color: Colors.grey[600],
              ),
            ),
            SizedBox(height: 32),
            _buildFeatureCard(
              context,
              'Özellik 1',
              'Bu özellik hakkında açıklama',
              Icons.star,
            ),
            SizedBox(height: 16),
            _buildFeatureCard(
              context,
              'Özellik 2',
              'Bu özellik hakkında açıklama',
              Icons.favorite,
            ),
            SizedBox(height: 16),
            _buildFeatureCard(
              context,
              'Özellik 3',
              'Bu özellik hakkında açıklama',
              Icons.thumb_up,
            ),
          ],
        ),
      ),
    );
  }}

  Widget _buildFeatureCard(BuildContext context, String title, String description, IconData icon) {{
    return Card(
      elevation: 4,
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: Row(
          children: [
            Icon(icon, size: 40, color: Colors.blue),
            SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    description,
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Colors.grey[600],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }}
}}
''',
                'type': 'dart'
            },
            'README.md': {
                'content': f'''# {project.name}

{project.description}

## Başlangıç

Bu proje AI App Builder ile oluşturulmuştur.

### Gereksinimler

- Flutter SDK 3.0+
- Dart 3.0+
- Android Studio / VS Code
- iOS Simulator / Android Emulator

### Kurulum

```bash
flutter pub get
```

### Çalıştırma

```bash
flutter run
```

### Build

#### Android
```bash
flutter build apk
```

#### iOS
```bash
flutter build ios
```

## Teknolojiler

- Flutter 3.0+
- Material Design
- Provider (State Management)

## Lisans

MIT
''',
                'type': 'markdown'
            }
        }
        
        return files

@export_bp.route('/project/<int:project_id>/export', methods=['POST'])
def export_project(project_id):
    """Export project as downloadable zip file"""
    
    project = Project.query.get_or_404(project_id)
    data = request.json or {}
    
    export_format = data.get('format', 'react')  # react, react-native, flutter
    include_ai_code = data.get('include_ai_code', True)
    
    try:
        # Create temporary directory
        temp_dir = tempfile.mkdtemp()
        project_dir = os.path.join(temp_dir, project.name.replace(' ', '-'))
        os.makedirs(project_dir, exist_ok=True)
        
        # Generate template files based on format
        if export_format == 'react':
            template_files = ProjectTemplates.generate_react_template(project)
        elif export_format == 'react-native':
            template_files = ProjectTemplates.generate_react_native_template(project)
        elif export_format == 'flutter':
            template_files = ProjectTemplates.generate_flutter_template(project)
        else:
            return jsonify({'error': 'Unsupported export format'}), 400
        
        # Write template files
        for file_path, file_data in template_files.items():
            full_path = os.path.join(project_dir, file_path)
            os.makedirs(os.path.dirname(full_path), exist_ok=True)
            
            with open(full_path, 'w', encoding='utf-8') as f:
                f.write(file_data['content'])
        
        # Include AI-generated code if requested
        if include_ai_code and project.generated_code:
            ai_code_dir = os.path.join(project_dir, 'ai-generated')
            os.makedirs(ai_code_dir, exist_ok=True)
            
            code_data = json.loads(project.generated_code)
            for file_info in code_data.get('files', []):
                ai_file_path = os.path.join(ai_code_dir, file_info['path'])
                os.makedirs(os.path.dirname(ai_file_path), exist_ok=True)
                
                with open(ai_file_path, 'w', encoding='utf-8') as f:
                    f.write(file_info['content'])
        
        # Create zip file
        zip_path = os.path.join(temp_dir, f"{project.name.replace(' ', '-')}.zip")
        
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(project_dir):
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, temp_dir)
                    zipf.write(file_path, arcname)
        
        # Return zip file
        return send_file(
            zip_path,
            as_attachment=True,
            download_name=f"{project.name.replace(' ', '-')}-{export_format}.zip",
            mimetype='application/zip'
        )
        
    except Exception as e:
        return jsonify({'error': f'Export failed: {str(e)}'}), 500
    finally:
        # Cleanup temp directory
        try:
            shutil.rmtree(temp_dir)
        except:
            pass

@export_bp.route('/project/<int:project_id>/preview', methods=['GET'])
def preview_project(project_id):
    """Generate preview of project structure"""
    
    project = Project.query.get_or_404(project_id)
    export_format = request.args.get('format', 'react')
    
    try:
        # Generate template files based on format
        if export_format == 'react':
            template_files = ProjectTemplates.generate_react_template(project)
        elif export_format == 'react-native':
            template_files = ProjectTemplates.generate_react_native_template(project)
        elif export_format == 'flutter':
            template_files = ProjectTemplates.generate_flutter_template(project)
        else:
            return jsonify({'error': 'Unsupported export format'}), 400
        
        # Create file structure preview
        file_structure = []
        for file_path, file_data in template_files.items():
            file_structure.append({
                'path': file_path,
                'type': file_data['type'],
                'size': len(file_data['content']),
                'preview': file_data['content'][:200] + '...' if len(file_data['content']) > 200 else file_data['content']
            })
        
        # Add AI-generated files if available
        ai_files = []
        if project.generated_code:
            code_data = json.loads(project.generated_code)
            for file_info in code_data.get('files', []):
                ai_files.append({
                    'path': f"ai-generated/{file_info['path']}",
                    'type': 'ai-generated',
                    'size': len(file_info['content']),
                    'description': file_info.get('description', ''),
                    'preview': file_info['content'][:200] + '...' if len(file_info['content']) > 200 else file_info['content']
                })
        
        return jsonify({
            'project_name': project.name,
            'export_format': export_format,
            'template_files': file_structure,
            'ai_generated_files': ai_files,
            'total_files': len(file_structure) + len(ai_files),
            'estimated_size': sum(f['size'] for f in file_structure) + sum(f['size'] for f in ai_files)
        })
        
    except Exception as e:
        return jsonify({'error': f'Preview generation failed: {str(e)}'}), 500

@export_bp.route('/templates', methods=['GET'])
def get_available_templates():
    """Get list of available project templates"""
    
    templates = [
        {
            'id': 'react',
            'name': 'React/Next.js',
            'description': 'Modern web application with Next.js and Tailwind CSS',
            'platforms': ['web'],
            'technologies': ['React', 'Next.js', 'Tailwind CSS', 'JavaScript'],
            'features': [
                'Server-side rendering',
                'Responsive design',
                'Modern UI components',
                'SEO optimized'
            ]
        },
        {
            'id': 'react-native',
            'name': 'React Native',
            'description': 'Cross-platform mobile application for iOS and Android',
            'platforms': ['ios', 'android'],
            'technologies': ['React Native', 'JavaScript', 'React Navigation'],
            'features': [
                'Cross-platform compatibility',
                'Native performance',
                'Hot reloading',
                'Rich ecosystem'
            ]
        },
        {
            'id': 'flutter',
            'name': 'Flutter',
            'description': 'High-performance mobile application with Flutter',
            'platforms': ['ios', 'android', 'web'],
            'technologies': ['Flutter', 'Dart', 'Material Design'],
            'features': [
                'Fast development',
                'Beautiful UI',
                'Hot reload',
                'Multi-platform'
            ]
        }
    ]
    
    return jsonify({
        'templates': templates,
        'total': len(templates)
    })

