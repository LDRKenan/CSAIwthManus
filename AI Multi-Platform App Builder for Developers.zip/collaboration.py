from flask import Blueprint, request
from flask_socketio import SocketIO, emit, join_room, leave_room, rooms
from src.models.project import Project, db
import json
import time

collaboration_bp = Blueprint('collaboration', __name__)

# Global SocketIO instance will be initialized in main.py
socketio = None

# Store active sessions and their cursors
active_sessions = {}
project_participants = {}

class OperationalTransform:
    """Simple Operational Transform implementation for text operations"""
    
    @staticmethod
    def transform_operation(op1, op2):
        """Transform two operations against each other"""
        # Simplified OT - in production, use a proper OT library
        if op1['type'] == 'insert' and op2['type'] == 'insert':
            if op1['position'] <= op2['position']:
                op2['position'] += len(op1['text'])
            else:
                op1['position'] += len(op2['text'])
        elif op1['type'] == 'delete' and op2['type'] == 'delete':
            if op1['position'] < op2['position']:
                op2['position'] -= op1['length']
            elif op1['position'] > op2['position']:
                op1['position'] -= op2['length']
        elif op1['type'] == 'insert' and op2['type'] == 'delete':
            if op1['position'] <= op2['position']:
                op2['position'] += len(op1['text'])
            else:
                op1['position'] -= op2['length']
        elif op1['type'] == 'delete' and op2['type'] == 'insert':
            if op2['position'] <= op1['position']:
                op1['position'] += len(op2['text'])
            else:
                op2['position'] -= op1['length']
        
        return op1, op2
    
    @staticmethod
    def apply_operation(text, operation):
        """Apply an operation to text"""
        if operation['type'] == 'insert':
            pos = operation['position']
            return text[:pos] + operation['text'] + text[pos:]
        elif operation['type'] == 'delete':
            pos = operation['position']
            length = operation['length']
            return text[:pos] + text[pos + length:]
        elif operation['type'] == 'replace':
            pos = operation['position']
            length = operation['length']
            return text[:pos] + operation['text'] + text[pos + length:]
        return text

def init_socketio(app):
    """Initialize SocketIO with the Flask app"""
    global socketio
    socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')
    
    @socketio.on('connect')
    def handle_connect():
        print(f'Client connected: {request.sid}')
        emit('connected', {'status': 'Connected to collaboration server'})
    
    @socketio.on('disconnect')
    def handle_disconnect():
        print(f'Client disconnected: {request.sid}')
        # Remove user from all project rooms
        for project_id in list(project_participants.keys()):
            if request.sid in project_participants[project_id]:
                project_participants[project_id].remove(request.sid)
                socketio.emit('user_left', {
                    'user_id': request.sid,
                    'project_id': project_id
                }, room=f'project_{project_id}')
                
                if len(project_participants[project_id]) == 0:
                    del project_participants[project_id]
    
    @socketio.on('join_project')
    def handle_join_project(data):
        project_id = data['project_id']
        user_name = data.get('user_name', f'User_{request.sid[:8]}')
        
        # Verify project exists
        project = Project.query.get(project_id)
        if not project:
            emit('error', {'message': 'Project not found'})
            return
        
        room = f'project_{project_id}'
        join_room(room)
        
        # Track participants
        if project_id not in project_participants:
            project_participants[project_id] = []
        
        if request.sid not in project_participants[project_id]:
            project_participants[project_id].append(request.sid)
        
        # Store session info
        active_sessions[request.sid] = {
            'project_id': project_id,
            'user_name': user_name,
            'cursor_position': 0,
            'current_file': None
        }
        
        # Notify other users
        emit('user_joined', {
            'user_id': request.sid,
            'user_name': user_name,
            'project_id': project_id
        }, room=room, include_self=False)
        
        # Send current project state
        emit('project_state', {
            'project': project.to_dict(),
            'participants': len(project_participants[project_id])
        })
        
        print(f'User {user_name} joined project {project_id}')
    
    @socketio.on('leave_project')
    def handle_leave_project(data):
        project_id = data['project_id']
        room = f'project_{project_id}'
        leave_room(room)
        
        if request.sid in active_sessions:
            user_name = active_sessions[request.sid]['user_name']
            del active_sessions[request.sid]
            
            # Remove from participants
            if project_id in project_participants and request.sid in project_participants[project_id]:
                project_participants[project_id].remove(request.sid)
                
                # Notify other users
                emit('user_left', {
                    'user_id': request.sid,
                    'user_name': user_name,
                    'project_id': project_id
                }, room=room)
                
                if len(project_participants[project_id]) == 0:
                    del project_participants[project_id]
    
    @socketio.on('code_change')
    def handle_code_change(data):
        if request.sid not in active_sessions:
            emit('error', {'message': 'Not in a project session'})
            return
        
        session = active_sessions[request.sid]
        project_id = session['project_id']
        room = f'project_{project_id}'
        
        # Get the operation details
        operation = {
            'type': data['type'],  # 'insert', 'delete', 'replace'
            'position': data['position'],
            'text': data.get('text', ''),
            'length': data.get('length', 0),
            'file_path': data['file_path'],
            'timestamp': time.time(),
            'user_id': request.sid,
            'user_name': session['user_name']
        }
        
        # Apply operational transform if needed
        # In a real implementation, you'd queue operations and transform them
        
        # Broadcast to other users in the room
        emit('code_operation', operation, room=room, include_self=False)
        
        # Update project in database
        try:
            project = Project.query.get(project_id)
            if project and project.generated_code:
                code_data = json.loads(project.generated_code)
                
                # Find and update the file
                for file_data in code_data.get('files', []):
                    if file_data['path'] == operation['file_path']:
                        # Apply the operation to the file content
                        file_data['content'] = OperationalTransform.apply_operation(
                            file_data['content'], operation
                        )
                        break
                
                project.set_generated_code(code_data)
                db.session.commit()
                
        except Exception as e:
            print(f'Error updating project: {e}')
    
    @socketio.on('cursor_position')
    def handle_cursor_position(data):
        if request.sid not in active_sessions:
            return
        
        session = active_sessions[request.sid]
        project_id = session['project_id']
        room = f'project_{project_id}'
        
        # Update cursor position
        session['cursor_position'] = data['position']
        session['current_file'] = data.get('file_path')
        
        # Broadcast cursor position to other users
        emit('user_cursor', {
            'user_id': request.sid,
            'user_name': session['user_name'],
            'position': data['position'],
            'file_path': data.get('file_path'),
            'selection': data.get('selection')
        }, room=room, include_self=False)
    
    @socketio.on('file_opened')
    def handle_file_opened(data):
        if request.sid not in active_sessions:
            return
        
        session = active_sessions[request.sid]
        project_id = session['project_id']
        room = f'project_{project_id}'
        
        session['current_file'] = data['file_path']
        
        # Notify other users which file this user is viewing
        emit('user_file_change', {
            'user_id': request.sid,
            'user_name': session['user_name'],
            'file_path': data['file_path']
        }, room=room, include_self=False)
    
    return socketio

@collaboration_bp.route('/project/<int:project_id>/participants', methods=['GET'])
def get_project_participants(project_id):
    """Get current participants in a project"""
    participants = project_participants.get(project_id, [])
    participant_info = []
    
    for session_id in participants:
        if session_id in active_sessions:
            session = active_sessions[session_id]
            participant_info.append({
                'user_id': session_id,
                'user_name': session['user_name'],
                'current_file': session.get('current_file'),
                'cursor_position': session.get('cursor_position', 0)
            })
    
    return {
        'participants': participant_info,
        'count': len(participant_info)
    }

@collaboration_bp.route('/project/<int:project_id>/history', methods=['GET'])
def get_project_history(project_id):
    """Get project change history (simplified)"""
    # In a real implementation, you'd store operation history in the database
    return {
        'history': [],
        'message': 'History feature coming soon'
    }

