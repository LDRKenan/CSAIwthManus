import { useState, useEffect } from 'react'
import Header from './components/Header'
import Hero from './components/Hero'
import Features from './components/Features'
import Pricing from './components/Pricing'
import AppBuilder from './components/AppBuilder'
import { Button } from '@/components/ui/button'
import './App.css'

function App() {
  const [showBuilder, setShowBuilder] = useState(false)
  const [projectData, setProjectData] = useState(null)

  useEffect(() => {
    // Check for URL hash and parameters
    const handleHashChange = () => {
      const hash = window.location.hash
      if (hash.includes('#app-builder')) {
        const urlParams = new URLSearchParams(hash.split('?')[1] || '')
        const idea = urlParams.get('idea')
        const platform = urlParams.get('platform')
        
        if (idea) {
          setProjectData({ idea, platform })
          setShowBuilder(true)
        } else {
          setShowBuilder(true)
        }
      } else {
        setShowBuilder(false)
        setProjectData(null)
      }
    }

    // Listen for hash changes
    window.addEventListener('hashchange', handleHashChange)
    
    // Check initial hash
    handleHashChange()

    return () => {
      window.removeEventListener('hashchange', handleHashChange)
    }
  }, [])

  if (showBuilder) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="container mx-auto py-8">
          <div className="mb-6">
            <Button 
              variant="outline" 
              onClick={() => {
                window.location.hash = ''
                setShowBuilder(false)
                setProjectData(null)
              }}
              className="mb-4"
            >
              ← Back to Home
            </Button>
          </div>
          <AppBuilder initialData={projectData} />
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <Hero />
        <Features />
        <Pricing />
        
        <section className="py-20 px-4 bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 text-white">
          <div className="container mx-auto max-w-4xl text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Ready to get started?
            </h2>
            <p className="text-xl mb-8 opacity-90">
              Creating your first app takes just a few minutes.
            </p>
            <Button 
              size="lg" 
              onClick={() => setShowBuilder(true)}
              className="bg-white text-purple-600 hover:bg-gray-100 text-lg px-8 py-6 rounded-2xl font-semibold shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105"
            >
              Start for Free
            </Button>
          </div>
        </section>
      </main>
      
      <footer className="bg-gray-900 text-white py-12 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="font-bold text-lg mb-4">AI App Builder</h3>
              <p className="text-gray-400 text-sm">
                From idea to app, fast development with AI.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Product</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li><a href="#features" className="hover:text-white">Features</a></li>
                <li><a href="#pricing" className="hover:text-white">Pricing</a></li>
                <li><a href="#templates" className="hover:text-white">Templates</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li><a href="#docs" className="hover:text-white">Documentation</a></li>
                <li><a href="#" className="hover:text-white">API Reference</a></li>
                <li><a href="#" className="hover:text-white">Contact</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li><a href="#" className="hover:text-white">About</a></li>
                <li><a href="#" className="hover:text-white">Blog</a></li>
                <li><a href="#" className="hover:text-white">Careers</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-400">
            <p>&copy; 2025 AI App Builder. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App

