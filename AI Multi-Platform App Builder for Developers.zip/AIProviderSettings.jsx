import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Settings, 
  Key, 
  Zap, 
  CheckCircle, 
  AlertCircle, 
  Loader2,
  BarChart3,
  DollarSign
} from 'lucide-react'

export default function AIProviderSettings() {
  const [providers, setProviders] = useState({})
  const [selectedProvider, setSelectedProvider] = useState('openai')
  const [apiKey, setApiKey] = useState('')
  const [selectedModel, setSelectedModel] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [testResult, setTestResult] = useState(null)
  const [usageStats, setUsageStats] = useState(null)

  useEffect(() => {
    fetchProviders()
    fetchUsageStats()
  }, [])

  const fetchProviders = async () => {
    try {
      const response = await fetch('https://60h5imcydw5z.manus.space/api/ai-providers')
      const data = await response.json()
      if (data.success) {
        setProviders(data.providers)
        if (data.providers.openai) {
          setSelectedModel(data.providers.openai.models[0])
        }
      }
    } catch (error) {
      console.error('Failed to fetch providers:', error)
    }
  }

  const fetchUsageStats = async () => {
    try {
      const response = await fetch('https://60h5imcydw5z.manus.space/api/ai-providers/usage')
      const data = await response.json()
      if (data.success) {
        setUsageStats(data.usage)
      }
    } catch (error) {
      console.error('Failed to fetch usage stats:', error)
    }
  }

  const handleTestConnection = async () => {
    if (!apiKey.trim()) {
      setTestResult({ success: false, message: 'Please enter an API key' })
      return
    }

    setIsLoading(true)
    setTestResult(null)

    try {
      const response = await fetch('https://60h5imcydw5z.manus.space/api/ai-providers/test', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          provider_id: selectedProvider,
          api_key: apiKey,
          model: selectedModel
        })
      })

      const data = await response.json()
      setTestResult(data)
    } catch (error) {
      setTestResult({ 
        success: false, 
        message: 'Failed to test connection' 
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleSaveConfiguration = async () => {
    if (!apiKey.trim()) {
      alert('Please enter an API key')
      return
    }

    setIsLoading(true)

    try {
      const response = await fetch('https://60h5imcydw5z.manus.space/api/ai-providers/configure', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          provider_id: selectedProvider,
          api_key: apiKey,
          model: selectedModel,
          custom_settings: {}
        })
      })

      const data = await response.json()
      if (data.success) {
        alert('Configuration saved successfully!')
      } else {
        alert('Failed to save configuration: ' + data.error)
      }
    } catch (error) {
      alert('Failed to save configuration')
    } finally {
      setIsLoading(false)
    }
  }

  const currentProvider = providers[selectedProvider]

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-2">AI Provider Settings</h2>
        <p className="text-gray-600">Configure your AI providers to customize code generation</p>
      </div>

      <Tabs defaultValue="configure" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="configure">Configure</TabsTrigger>
          <TabsTrigger value="usage">Usage Stats</TabsTrigger>
          <TabsTrigger value="models">Available Models</TabsTrigger>
        </TabsList>

        <TabsContent value="configure" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="w-5 h-5" />
                Provider Configuration
              </CardTitle>
              <CardDescription>
                Select and configure your preferred AI provider
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Provider Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Select AI Provider
                </label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {Object.entries(providers).map(([id, provider]) => (
                    <button
                      key={id}
                      onClick={() => {
                        setSelectedProvider(id)
                        setSelectedModel(provider.models[0])
                        setTestResult(null)
                      }}
                      className={`p-4 border-2 rounded-lg text-left transition-all ${
                        selectedProvider === id
                          ? 'border-blue-500 bg-blue-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <div className="font-medium text-gray-900">{provider.name}</div>
                      <div className="text-sm text-gray-500 mt-1">{provider.description}</div>
                      <Badge variant="secondary" className="mt-2">
                        {provider.models.length} models
                      </Badge>
                    </button>
                  ))}
                </div>
              </div>

              {currentProvider && (
                <>
                  {/* Model Selection */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Select Model
                    </label>
                    <select
                      value={selectedModel}
                      onChange={(e) => setSelectedModel(e.target.value)}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    >
                      {currentProvider.models.map((model) => (
                        <option key={model} value={model}>
                          {model}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* API Key Input */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      API Key
                    </label>
                    <div className="relative">
                      <Key className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                      <Input
                        type="password"
                        value={apiKey}
                        onChange={(e) => setApiKey(e.target.value)}
                        placeholder={`Enter your ${currentProvider.name} API key`}
                        className="pl-10"
                      />
                    </div>
                    <p className="text-sm text-gray-500 mt-1">
                      Your API key is encrypted and stored securely
                    </p>
                  </div>

                  {/* Test Connection */}
                  <div className="flex gap-3">
                    <Button
                      onClick={handleTestConnection}
                      disabled={isLoading || !apiKey.trim()}
                      variant="outline"
                      className="flex items-center gap-2"
                    >
                      {isLoading ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <Zap className="w-4 h-4" />
                      )}
                      Test Connection
                    </Button>

                    <Button
                      onClick={handleSaveConfiguration}
                      disabled={isLoading || !apiKey.trim()}
                      className="flex items-center gap-2"
                    >
                      {isLoading ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <CheckCircle className="w-4 h-4" />
                      )}
                      Save Configuration
                    </Button>
                  </div>

                  {/* Test Result */}
                  {testResult && (
                    <div className={`p-4 rounded-lg border ${
                      testResult.success 
                        ? 'border-green-200 bg-green-50' 
                        : 'border-red-200 bg-red-50'
                    }`}>
                      <div className="flex items-center gap-2">
                        {testResult.success ? (
                          <CheckCircle className="w-5 h-5 text-green-600" />
                        ) : (
                          <AlertCircle className="w-5 h-5 text-red-600" />
                        )}
                        <span className={`font-medium ${
                          testResult.success ? 'text-green-900' : 'text-red-900'
                        }`}>
                          {testResult.message}
                        </span>
                      </div>
                      {testResult.test_response && (
                        <div className="mt-2 text-sm text-gray-600">
                          Model: {testResult.test_response.model} | 
                          Response Time: {testResult.test_response.response_time} | 
                          Status: {testResult.test_response.status}
                        </div>
                      )}
                    </div>
                  )}
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="usage" className="space-y-6">
          {usageStats && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Requests</CardTitle>
                  <BarChart3 className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{usageStats.total_requests.toLocaleString()}</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Tokens</CardTitle>
                  <Zap className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{usageStats.total_tokens.toLocaleString()}</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Cost</CardTitle>
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">${usageStats.total_cost.toFixed(2)}</div>
                </CardContent>
              </Card>
            </div>
          )}
        </TabsContent>

        <TabsContent value="models" className="space-y-6">
          <div className="grid gap-4">
            {Object.entries(providers).map(([id, provider]) => (
              <Card key={id}>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    {provider.name}
                    <Badge variant="outline">{provider.models.length} models</Badge>
                  </CardTitle>
                  <CardDescription>{provider.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {provider.models.map((model) => (
                      <Badge key={model} variant="secondary">
                        {model}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

