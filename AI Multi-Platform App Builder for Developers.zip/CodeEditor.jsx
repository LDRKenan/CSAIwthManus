import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Copy, Download, Play, Save, Monitor, Smartphone, Tablet } from 'lucide-react'

export default function CodeEditor({ project, selectedPlatform, onPlatformChange }) {
  const [selectedFile, setSelectedFile] = useState(null)
  const [fileContent, setFileContent] = useState('')

  useEffect(() => {
    if (project?.generated_code?.files?.length > 0) {
      // Find the first file for the selected platform
      const platformFiles = project.generated_code.files.filter(file => 
        file.platform === selectedPlatform || !file.platform
      )
      if (platformFiles.length > 0) {
        setSelectedFile(platformFiles[0])
        setFileContent(platformFiles[0].content || '')
      }
    }
  }, [project, selectedPlatform])

  const getPlatformFiles = (platform) => {
    if (!project?.generated_code?.files) return []
    return project.generated_code.files.filter(file => 
      file.platform === platform || (!file.platform && platform === 'web')
    )
  }

  const handleFileSelect = (file) => {
    setSelectedFile(file)
    setFileContent(file.content || '')
  }

  const handleCopyCode = () => {
    navigator.clipboard.writeText(fileContent)
    // You could add a toast notification here
  }

  const handleSaveFile = () => {
    // In a real implementation, this would save to the backend
    console.log('Saving file:', selectedFile?.path)
  }

  const handleDownloadFile = () => {
    if (!selectedFile) return
    
    const blob = new Blob([fileContent], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = selectedFile.path
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const getFileLanguage = (filename) => {
    const ext = filename.split('.').pop()?.toLowerCase()
    switch (ext) {
      case 'js':
      case 'jsx':
        return 'javascript'
      case 'ts':
      case 'tsx':
        return 'typescript'
      case 'css':
        return 'css'
      case 'html':
        return 'html'
      case 'json':
        return 'json'
      case 'xml':
        return 'xml'
      default:
        return 'text'
    }
  }

  const getPlatformIcon = (platform) => {
    switch (platform) {
      case 'web':
        return Monitor
      case 'android':
      case 'ios':
      case 'mobile':
        return Smartphone
      default:
        return Monitor
    }
  }

  if (!project) {
    return (
      <Card>
        <CardContent className="text-center py-12">
          <p className="text-gray-600">No project loaded</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Code Editor - {project.name}</span>
            <div className="flex gap-2">
              {project.platforms.map(platform => {
                const Icon = getPlatformIcon(platform)
                return (
                  <Button
                    key={platform}
                    variant={selectedPlatform === platform ? "default" : "outline"}
                    size="sm"
                    onClick={() => onPlatformChange(platform)}
                    className="capitalize"
                  >
                    <Icon className="w-4 h-4 mr-1" />
                    {platform}
                  </Button>
                )
              })}
            </div>
          </CardTitle>
          <CardDescription>
            Edit and customize your generated code for {selectedPlatform}
          </CardDescription>
        </CardHeader>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* File Explorer */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="text-lg">Project Files</CardTitle>
            <CardDescription>
              {selectedPlatform.charAt(0).toUpperCase() + selectedPlatform.slice(1)} Platform
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {getPlatformFiles(selectedPlatform).map((file, index) => (
                <Button
                  key={index}
                  variant={selectedFile?.path === file.path ? "default" : "ghost"}
                  className="w-full justify-start h-auto p-3"
                  onClick={() => handleFileSelect(file)}
                >
                  <div className="text-left">
                    <div className="font-medium text-sm">{file.path}</div>
                    <div className="text-xs text-gray-500 mt-1">
                      {file.description || 'Generated file'}
                    </div>
                  </div>
                </Button>
              ))}
              
              {getPlatformFiles(selectedPlatform).length === 0 && (
                <p className="text-sm text-gray-500 text-center py-4">
                  No files generated for {selectedPlatform}
                </p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Code Editor */}
        <Card className="lg:col-span-3">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-lg">
                  {selectedFile ? selectedFile.path : 'Select a file'}
                </CardTitle>
                {selectedFile && (
                  <CardDescription>
                    {selectedFile.description}
                  </CardDescription>
                )}
              </div>
              
              {selectedFile && (
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={handleCopyCode}>
                    <Copy className="w-4 h-4 mr-1" />
                    Copy
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleSaveFile}>
                    <Save className="w-4 h-4 mr-1" />
                    Save
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleDownloadFile}>
                    <Download className="w-4 h-4 mr-1" />
                    Download
                  </Button>
                </div>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {selectedFile ? (
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <Badge variant="secondary">
                    {getFileLanguage(selectedFile.path)}
                  </Badge>
                  <Badge variant="outline">
                    {selectedPlatform}
                  </Badge>
                  <span className="text-sm text-gray-500">
                    {fileContent.split('\n').length} lines
                  </span>
                </div>
                
                <div className="border rounded-lg overflow-hidden">
                  <textarea
                    value={fileContent}
                    onChange={(e) => setFileContent(e.target.value)}
                    className="w-full h-96 p-4 font-mono text-sm bg-gray-50 border-0 resize-none focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="File content will appear here..."
                    spellCheck={false}
                  />
                </div>
                
                <div className="flex justify-between items-center text-sm text-gray-500">
                  <span>
                    Generated with AI • {new Date().toLocaleDateString()}
                  </span>
                  <span>
                    Platform: {selectedPlatform}
                  </span>
                </div>
              </div>
            ) : (
              <div className="text-center py-12">
                <div className="text-gray-400 mb-4">
                  <Monitor className="w-12 h-12 mx-auto" />
                </div>
                <h3 className="text-lg font-medium mb-2">Select a File</h3>
                <p className="text-gray-600">
                  Choose a file from the project explorer to view and edit its code
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Platform Comparison */}
      {project.platforms.length > 1 && (
        <Card>
          <CardHeader>
            <CardTitle>Platform Comparison</CardTitle>
            <CardDescription>
              Compare the same functionality across different platforms
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue={project.platforms[0]} className="w-full">
              <TabsList className="grid w-full grid-cols-2 lg:grid-cols-4">
                {project.platforms.map(platform => {
                  const Icon = getPlatformIcon(platform)
                  return (
                    <TabsTrigger key={platform} value={platform} className="capitalize">
                      <Icon className="w-4 h-4 mr-1" />
                      {platform}
                    </TabsTrigger>
                  )
                })}
              </TabsList>
              
              {project.platforms.map(platform => (
                <TabsContent key={platform} value={platform} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {getPlatformFiles(platform).slice(0, 3).map((file, index) => (
                      <Card key={index}>
                        <CardHeader>
                          <CardTitle className="text-sm">{file.path}</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <pre className="text-xs bg-gray-50 p-2 rounded overflow-hidden">
                            {file.content?.substring(0, 200)}...
                          </pre>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>
              ))}
            </Tabs>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

