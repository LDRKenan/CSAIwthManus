from flask import Blueprint, request, jsonify
from flask_cors import cross_origin
import json
import os

ai_providers_bp = Blueprint('ai_providers', __name__)

# Supported AI providers configuration
AI_PROVIDERS = {
    'openai': {
        'name': 'OpenAI',
        'models': ['gpt-4', 'gpt-3.5-turbo', 'dall-e-3'],
        'api_key_required': True,
        'base_url': 'https://api.openai.com/v1',
        'description': 'Most popular AI provider with GPT models'
    },
    'anthropic': {
        'name': 'Anthropic',
        'models': ['claude-3-opus', 'claude-3-sonnet', 'claude-3-haiku'],
        'api_key_required': True,
        'base_url': 'https://api.anthropic.com',
        'description': 'Safe and helpful AI assistant'
    },
    'google': {
        'name': 'Google AI',
        'models': ['gemini-pro', 'gemini-pro-vision'],
        'api_key_required': True,
        'base_url': 'https://generativelanguage.googleapis.com/v1',
        'description': 'Google\'s advanced AI models'
    },
    'huggingface': {
        'name': 'Hugging Face',
        'models': ['meta-llama/Llama-2-7b-chat-hf', 'microsoft/DialoGPT-medium'],
        'api_key_required': True,
        'base_url': 'https://api-inference.huggingface.co',
        'description': 'Open-source AI models community'
    },
    'cohere': {
        'name': 'Cohere',
        'models': ['command', 'command-light', 'command-nightly'],
        'api_key_required': True,
        'base_url': 'https://api.cohere.ai/v1',
        'description': 'Enterprise AI platform'
    },
    'mistral': {
        'name': 'Mistral AI',
        'models': ['mistral-tiny', 'mistral-small', 'mistral-medium'],
        'api_key_required': True,
        'base_url': 'https://api.mistral.ai/v1',
        'description': 'European AI company with efficient models'
    }
}

@ai_providers_bp.route('/api/ai-providers', methods=['GET'])
@cross_origin()
def get_ai_providers():
    """Get list of supported AI providers"""
    return jsonify({
        'success': True,
        'providers': AI_PROVIDERS
    })

@ai_providers_bp.route('/api/ai-providers/configure', methods=['POST'])
@cross_origin()
def configure_ai_provider():
    """Configure AI provider settings for a user"""
    data = request.get_json()
    
    provider_id = data.get('provider_id')
    api_key = data.get('api_key')
    model = data.get('model')
    custom_settings = data.get('custom_settings', {})
    
    if not provider_id or provider_id not in AI_PROVIDERS:
        return jsonify({
            'success': False,
            'error': 'Invalid provider ID'
        }), 400
    
    if not api_key:
        return jsonify({
            'success': False,
            'error': 'API key is required'
        }), 400
    
    # In a real implementation, you would save this to a database
    # For now, we'll just return success
    configuration = {
        'provider_id': provider_id,
        'provider_name': AI_PROVIDERS[provider_id]['name'],
        'model': model,
        'custom_settings': custom_settings,
        'configured_at': '2025-01-01T00:00:00Z'
    }
    
    return jsonify({
        'success': True,
        'message': f'{AI_PROVIDERS[provider_id]["name"]} configured successfully',
        'configuration': configuration
    })

@ai_providers_bp.route('/api/ai-providers/test', methods=['POST'])
@cross_origin()
def test_ai_provider():
    """Test AI provider connection"""
    data = request.get_json()
    
    provider_id = data.get('provider_id')
    api_key = data.get('api_key')
    model = data.get('model')
    
    if not provider_id or provider_id not in AI_PROVIDERS:
        return jsonify({
            'success': False,
            'error': 'Invalid provider ID'
        }), 400
    
    # Mock test - in real implementation, you would make actual API call
    return jsonify({
        'success': True,
        'message': f'Connection to {AI_PROVIDERS[provider_id]["name"]} successful',
        'test_response': {
            'model': model,
            'response_time': '0.5s',
            'status': 'healthy'
        }
    })

@ai_providers_bp.route('/api/ai-providers/generate', methods=['POST'])
@cross_origin()
def generate_with_custom_provider():
    """Generate code using custom AI provider"""
    data = request.get_json()
    
    provider_id = data.get('provider_id')
    prompt = data.get('prompt')
    model = data.get('model')
    project_context = data.get('project_context', {})
    
    if not provider_id or provider_id not in AI_PROVIDERS:
        return jsonify({
            'success': False,
            'error': 'Invalid provider ID'
        }), 400
    
    # Mock generation - in real implementation, you would use the actual AI provider
    mock_response = {
        'provider': AI_PROVIDERS[provider_id]['name'],
        'model': model,
        'generated_code': f'''
// Generated using {AI_PROVIDERS[provider_id]['name']} - {model}
// Project: {project_context.get('name', 'Untitled')}

import React from 'react';

const {project_context.get('name', 'App').replace(' ', '')}Component = () => {{
  return (
    <div className="container">
      <h1>{project_context.get('name', 'My App')}</h1>
      <p>{project_context.get('description', 'Generated with AI')}</p>
      <div className="features">
        <h2>AI-Generated Features:</h2>
        <ul>
          <li>Responsive design</li>
          <li>Modern UI components</li>
          <li>Optimized performance</li>
        </ul>
      </div>
    </div>
  );
}};

export default {project_context.get('name', 'App').replace(' ', '')}Component;
        ''',
        'metadata': {
            'tokens_used': 150,
            'generation_time': '1.2s',
            'cost_estimate': '$0.003'
        }
    }
    
    return jsonify({
        'success': True,
        'result': mock_response
    })

@ai_providers_bp.route('/api/ai-providers/usage', methods=['GET'])
@cross_origin()
def get_usage_stats():
    """Get AI provider usage statistics"""
    # Mock usage data
    usage_stats = {
        'total_requests': 1250,
        'total_tokens': 45000,
        'total_cost': 12.50,
        'providers': {
            'openai': {
                'requests': 800,
                'tokens': 30000,
                'cost': 8.50
            },
            'anthropic': {
                'requests': 300,
                'tokens': 10000,
                'cost': 3.00
            },
            'google': {
                'requests': 150,
                'tokens': 5000,
                'cost': 1.00
            }
        },
        'daily_usage': [
            {'date': '2025-01-15', 'requests': 45, 'cost': 0.85},
            {'date': '2025-01-16', 'requests': 52, 'cost': 1.20},
            {'date': '2025-01-17', 'requests': 38, 'cost': 0.95},
            {'date': '2025-01-18', 'requests': 61, 'cost': 1.45},
            {'date': '2025-01-19', 'requests': 44, 'cost': 1.05}
        ]
    }
    
    return jsonify({
        'success': True,
        'usage': usage_stats
    })

