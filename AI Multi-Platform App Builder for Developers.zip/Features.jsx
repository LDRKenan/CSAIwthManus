import { 
  Code2, 
  Smartphone, 
  Users, 
  Download, 
  Palette, 
  Zap,
  GitBranch,
  Rocket,
  Gamepad2,
  Glasses,
  Plug
} from 'lucide-react'

export default function Features() {
  const features = [
    {
      icon: Code2,
      title: "AI Code Generation",
      description: "Transform natural language descriptions into production-ready, full-stack code.",
      badge: "Core",
      badgeColor: "bg-blue-100 text-blue-700",
      gradient: "from-blue-500 to-cyan-500"
    },
    {
      icon: Smartphone,
      title: "Multi-Platform Support",
      description: "Build for Android, iOS, and Web simultaneously with a single project.",
      badge: "Popular",
      badgeColor: "bg-green-100 text-green-700",
      gradient: "from-green-500 to-emerald-500"
    },
    {
      icon: Users,
      title: "Real-Time Collaboration",
      description: "Google Docs-like real-time code editing and team collaboration.",
      badge: "Pro",
      badgeColor: "bg-purple-100 text-purple-700",
      gradient: "from-purple-500 to-violet-500"
    },
    {
      icon: Download,
      title: "Complete Code Export",
      description: "Download full React, Flutter, Node.js projects and customize them.",
      badge: "Essential",
      badgeColor: "bg-orange-100 text-orange-700",
      gradient: "from-orange-500 to-red-500"
    },
    {
      icon: Palette,
      title: "AI UI/UX Design",
      description: "Automatic UI/UX design and theme generation based on app type.",
      badge: "New",
      badgeColor: "bg-pink-100 text-pink-700",
      gradient: "from-pink-500 to-rose-500"
    },
    {
      icon: Rocket,
      title: "Instant Deployment",
      description: "Deploy generated applications instantly and test them live.",
      badge: "Fast",
      badgeColor: "bg-indigo-100 text-indigo-700",
      gradient: "from-indigo-500 to-blue-500"
    },
    {
      icon: GitBranch,
      title: "Version Control",
      description: "Project history, branching, and change tracking built-in.",
      badge: "Advanced",
      badgeColor: "bg-gray-100 text-gray-700",
      gradient: "from-gray-500 to-slate-500"
    },
    {
      icon: Zap,
      title: "Rapid Prototyping",
      description: "From idea to working prototype in just 60 seconds.",
      badge: "Lightning",
      badgeColor: "bg-yellow-100 text-yellow-700",
      gradient: "from-yellow-500 to-amber-500"
    }
  ]

  const roadmapFeatures = [
    {
      icon: Gamepad2,
      title: "Game Development",
      description: "Unity and Unreal Engine support",
      color: "text-purple-600"
    },
    {
      icon: Glasses,
      title: "AR Support",
      description: "Augmented reality applications",
      color: "text-blue-600"
    },
    {
      icon: Plug,
      title: "API Marketplace",
      description: "Ready-to-use API integrations",
      color: "text-green-600"
    }
  ]

  return (
    <section id="features" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="bg-gradient-to-r from-gray-900 to-gray-600 bg-clip-text text-transparent">
              Powerful Tools for
            </span>
            <br />
            <span className="bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              Developers
            </span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            AI-powered features that accelerate and simplify professional application development.
          </p>
        </div>

        {/* Main Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          {features.map((feature, index) => (
            <div
              key={index}
              className="group relative bg-white rounded-2xl p-6 border border-gray-100 hover:border-gray-200 transition-all duration-300 hover:shadow-xl hover:-translate-y-1"
            >
              {/* Badge */}
              <div className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium mb-4 ${feature.badgeColor}`}>
                {feature.badge}
              </div>

              {/* Icon */}
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-r ${feature.gradient} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                <feature.icon className="w-6 h-6 text-white" />
              </div>

              {/* Content */}
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                {feature.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {feature.description}
              </p>

              {/* Hover Effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-purple-500/5 to-blue-500/5 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </div>
          ))}
        </div>

        {/* Future Roadmap */}
        <div className="bg-gradient-to-br from-gray-50 to-blue-50 rounded-3xl p-8 md:p-12">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">Future Roadmap</h3>
            <p className="text-lg text-gray-600">Exciting features coming soon</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {roadmapFeatures.map((feature, index) => (
              <div
                key={index}
                className="text-center group"
              >
                <div className={`w-16 h-16 mx-auto mb-4 rounded-2xl bg-white shadow-lg flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                  <feature.icon className={`w-8 h-8 ${feature.color}`} />
                </div>
                <h4 className="text-xl font-semibold text-gray-900 mb-2">
                  {feature.title}
                </h4>
                <p className="text-gray-600">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center mt-16">
          <h3 className="text-3xl font-bold text-gray-900 mb-4">
            Ready to get started?
          </h3>
          <p className="text-lg text-gray-600 mb-8">
            Creating your first app takes just a few minutes.
          </p>
          <button className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-semibold py-4 px-8 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105">
            Start for Free
          </button>
        </div>
      </div>
    </section>
  )
}

