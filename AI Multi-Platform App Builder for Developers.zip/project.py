from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import json

db = SQLAlchemy()

class Project(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    app_type = db.Column(db.String(50), nullable=False)  # e.g., "Instagram clone", "Food delivery app"
    platforms = db.Column(db.Text, nullable=False)  # JSON string: ["web", "mobile", "ios", "android"]
    generated_code = db.Column(db.Text)  # JSON string containing generated code files
    architecture = db.Column(db.Text)  # JSON string containing project architecture
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'app_type': self.app_type,
            'platforms': json.loads(self.platforms) if self.platforms else [],
            'generated_code': json.loads(self.generated_code) if self.generated_code else {},
            'architecture': json.loads(self.architecture) if self.architecture else {},
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
            'user_id': self.user_id
        }
    
    def set_platforms(self, platforms_list):
        self.platforms = json.dumps(platforms_list)
    
    def set_generated_code(self, code_dict):
        self.generated_code = json.dumps(code_dict)
    
    def set_architecture(self, architecture_dict):
        self.architecture = json.dumps(architecture_dict)

