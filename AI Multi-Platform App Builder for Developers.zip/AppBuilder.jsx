import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Checkbox } from '@/components/ui/checkbox'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Loader2, Sparkles, Code, Download, Play, CheckCircle, Settings, Eye, Smartphone, Monitor, Tablet } from 'lucide-react'
import CodeEditor from './CodeEditor'
import AIProviderSettings from './AIProviderSettings'
import AppPreview from './AppPreview'

export default function AppBuilder({ initialData }) {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    platforms: [],
    appType: 'web-app'
  })
  const [isGenerating, setIsGenerating] = useState(false)
  const [generatedProject, setGeneratedProject] = useState(null)
  const [showCodeEditor, setShowCodeEditor] = useState(false)
  const [generationSteps, setGenerationSteps] = useState([])
  const [activeTab, setActiveTab] = useState('builder')
  const [selectedPlatform, setSelectedPlatform] = useState('web')

  // Initialize form data from URL parameters
  useEffect(() => {
    if (initialData) {
      setFormData(prev => ({
        ...prev,
        description: initialData.idea || '',
        platforms: initialData.platform ? [initialData.platform.toLowerCase()] : []
      }))
    }
  }, [initialData])

  const platforms = [
    { id: 'web', label: 'Web', description: 'React/Next.js web application', icon: Monitor },
    { id: 'mobile', label: 'Mobile', description: 'React Native iOS & Android', icon: Smartphone },
    { id: 'ios', label: 'iOS Only', description: 'Native iOS application', icon: Smartphone },
    { id: 'android', label: 'Android Only', description: 'Native Android application', icon: Smartphone }
  ]

  const appTypes = [
    { id: 'web-app', label: 'Web Application', description: 'Interactive web application' },
    { id: 'mobile-app', label: 'Mobile App', description: 'Native mobile application' },
    { id: 'e-commerce', label: 'E-commerce', description: 'Online store with payment' },
    { id: 'social-media', label: 'Social Media', description: 'Social networking platform' },
    { id: 'productivity', label: 'Productivity', description: 'Task management & tools' },
    { id: 'game', label: 'Game', description: 'Interactive game application' }
  ]

  const handlePlatformChange = (platformId) => {
    setFormData(prev => ({
      ...prev,
      platforms: prev.platforms.includes(platformId)
        ? prev.platforms.filter(p => p !== platformId)
        : [...prev.platforms, platformId]
    }))
  }

  const handleGenerate = async () => {
    if (!formData.name || !formData.description || formData.platforms.length === 0) {
      alert('Please fill in all required fields and select at least one platform.')
      return
    }

    setIsGenerating(true)
    setGenerationSteps([])
    
    // Enhanced AI generation steps
    const steps = [
      'Analyzing project requirements...',
      'Connecting to Mistral AI (Large Model)...',
      'Generating project architecture...',
      'Creating platform-specific components...',
      'Generating Web application code...',
      formData.platforms.includes('android') ? 'Generating Android application code...' : null,
      formData.platforms.includes('ios') ? 'Generating iOS application code...' : null,
      formData.platforms.includes('mobile') ? 'Generating cross-platform mobile code...' : null,
      'Setting up backend structure...',
      'Configuring database models...',
      'Generating API endpoints...',
      'Creating UI/UX designs...',
      'Optimizing code structure...',
      'Finalizing project files...'
    ].filter(Boolean)

    // Simulate step-by-step generation with realistic timing
    for (let i = 0; i < steps.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 800))
      setGenerationSteps(prev => [...prev, { step: steps[i], completed: true }])
    }

    try {
      // Call real Mistral AI API
      const response = await fetch('https://e5h6i7cnop3p.manus.space/api/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: formData.name,
          description: formData.description,
          platforms: formData.platforms,
          appType: formData.appType
        })
      })

      if (response.ok) {
        const result = await response.json()
        if (result.success) {
          setGeneratedProject(result.project)
          setActiveTab('preview') // Switch to preview tab after generation
          
          // Set default platform for viewing
          if (result.project.platforms.includes('web')) {
            setSelectedPlatform('web')
          } else if (result.project.platforms.includes('android')) {
            setSelectedPlatform('android')
          } else if (result.project.platforms.includes('ios')) {
            setSelectedPlatform('ios')
          }
        } else {
          throw new Error(result.message || 'Generation failed')
        }
      } else {
        throw new Error('API request failed')
      }
    } catch (error) {
      console.error('Error generating project:', error)
      alert(`Generation failed: ${error.message}. Please try again.`)
    }
    
    setIsGenerating(false)
  }

  const handleDownload = () => {
    if (!generatedProject) return

    // Create comprehensive project export
    const projectData = {
      name: generatedProject.name,
      description: generatedProject.description,
      platforms: generatedProject.platforms,
      appType: generatedProject.appType,
      files: generatedProject.generated_code.files,
      platformSpecific: generatedProject.generated_code.platform_specific,
      architecture: generatedProject.architecture,
      generatedAt: new Date().toISOString()
    }
    
    const blob = new Blob([JSON.stringify(projectData, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${generatedProject.name.replace(/\s+/g, '-')}-complete-project.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const getPlatformFiles = (platform) => {
    if (!generatedProject?.generated_code?.files) return []
    return generatedProject.generated_code.files.filter(file => 
      file.platform === platform || !file.platform
    )
  }

  const getPlatformInfo = (platform) => {
    if (!generatedProject?.generated_code?.platform_specific) return null
    return generatedProject.generated_code.platform_specific[platform]
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-center mb-2">Create Your App with AI</h1>
        <p className="text-gray-600 text-center">Describe your project and let AI generate the complete application for you</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="builder" className="flex items-center gap-2">
            <Settings className="w-4 h-4" />
            App Builder
          </TabsTrigger>
          <TabsTrigger value="preview" className="flex items-center gap-2">
            <Eye className="w-4 h-4" />
            Live Preview
          </TabsTrigger>
          <TabsTrigger value="code" className="flex items-center gap-2">
            <Code className="w-4 h-4" />
            Code Editor
          </TabsTrigger>
          <TabsTrigger value="settings" className="flex items-center gap-2">
            <Settings className="w-4 h-4" />
            AI Settings
          </TabsTrigger>
        </TabsList>

        <TabsContent value="builder" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-purple-500" />
                Project Details
              </CardTitle>
              <CardDescription>
                Tell us about your project and we'll generate the code for you
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <label className="block text-sm font-medium mb-2">Project Name *</label>
                <Input
                  placeholder="e.g., My Awesome App"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Project Description *</label>
                <Textarea
                  placeholder="Describe your app idea in detail..."
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                  rows={4}
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-4">App Type</label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {appTypes.map((type) => (
                    <Button
                      key={type.id}
                      variant={formData.appType === type.id ? "default" : "outline"}
                      className="h-auto p-4 flex flex-col items-start"
                      onClick={() => setFormData(prev => ({ ...prev, appType: type.id }))}
                    >
                      <div className="font-medium">{type.label}</div>
                      <div className="text-xs text-gray-500 mt-1">{type.description}</div>
                    </Button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-4">Target Platforms *</label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {platforms.map((platform) => {
                    const Icon = platform.icon
                    return (
                      <div key={platform.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={platform.id}
                          checked={formData.platforms.includes(platform.id)}
                          onCheckedChange={() => handlePlatformChange(platform.id)}
                        />
                        <label htmlFor={platform.id} className="flex items-center gap-2 cursor-pointer">
                          <Icon className="w-4 h-4" />
                          <div>
                            <div className="font-medium">{platform.label}</div>
                            <div className="text-xs text-gray-500">{platform.description}</div>
                          </div>
                        </label>
                      </div>
                    )
                  })}
                </div>
              </div>

              <Button
                onClick={handleGenerate}
                disabled={isGenerating || !formData.name || !formData.description || formData.platforms.length === 0}
                className="w-full h-12 text-lg"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Generating Your App...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-5 h-5 mr-2" />
                    Generate App with AI
                  </>
                )}
              </Button>

              {isGenerating && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">AI Generation Progress</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {generationSteps.map((step, index) => (
                        <div key={index} className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-500" />
                          <span className="text-sm">{step.step}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="preview" className="space-y-6">
          {generatedProject ? (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>Live Preview - {generatedProject.name}</span>
                    <div className="flex gap-2">
                      {generatedProject.platforms.map(platform => (
                        <Button
                          key={platform}
                          variant={selectedPlatform === platform ? "default" : "outline"}
                          size="sm"
                          onClick={() => setSelectedPlatform(platform)}
                          className="capitalize"
                        >
                          {platform}
                        </Button>
                      ))}
                    </div>
                  </CardTitle>
                  <CardDescription>
                    See how your application looks across different platforms
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <AppPreview 
                    project={generatedProject} 
                    platform={selectedPlatform}
                  />
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Platform-Specific Information</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {generatedProject.platforms.map(platform => {
                      const platformInfo = getPlatformInfo(platform)
                      const files = getPlatformFiles(platform)
                      
                      return (
                        <Card key={platform}>
                          <CardHeader>
                            <CardTitle className="capitalize text-lg">{platform}</CardTitle>
                          </CardHeader>
                          <CardContent>
                            {platformInfo && (
                              <div className="space-y-3">
                                <div>
                                  <h4 className="font-medium mb-2">Tech Stack</h4>
                                  <div className="flex flex-wrap gap-1">
                                    {platformInfo.tech_stack?.map(tech => (
                                      <Badge key={tech} variant="secondary">{tech}</Badge>
                                    ))}
                                  </div>
                                </div>
                                <div>
                                  <h4 className="font-medium mb-2">Deployment</h4>
                                  <p className="text-sm text-gray-600">{platformInfo.deployment}</p>
                                </div>
                                <div>
                                  <h4 className="font-medium mb-2">Files Generated</h4>
                                  <p className="text-sm text-gray-600">{files.length} files</p>
                                </div>
                              </div>
                            )}
                          </CardContent>
                        </Card>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            <Card>
              <CardContent className="text-center py-12">
                <Eye className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">No Preview Available</h3>
                <p className="text-gray-600">Generate an app first to see the live preview</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="code" className="space-y-6">
          {generatedProject ? (
            <CodeEditor 
              project={generatedProject}
              selectedPlatform={selectedPlatform}
              onPlatformChange={setSelectedPlatform}
            />
          ) : (
            <Card>
              <CardContent className="text-center py-12">
                <Code className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">No Code Available</h3>
                <p className="text-gray-600">Generate an app first to view and edit the code</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="settings">
          <AIProviderSettings />
        </TabsContent>
      </Tabs>

      {generatedProject && (
        <div className="fixed bottom-6 right-6 flex gap-3">
          <Button onClick={handleDownload} className="shadow-lg">
            <Download className="w-4 h-4 mr-2" />
            Download Project
          </Button>
        </div>
      )}
    </div>
  )
}

